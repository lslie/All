from distutils.core import setup
setup(name="shejiyouxi",version="1.0",author="none",author_email="likeccpo@gmail.com",py_modules=["bullte.sheji"])
